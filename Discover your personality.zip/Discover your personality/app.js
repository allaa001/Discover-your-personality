const questions = [
    "Do you like teamwork?",
    "Do you enjoy reading?",
    "Do you like traveling?",
    "Do you enjoy sports?",
    "Do you like cooking?",
    "Do you prefer working in a team?",
    "Do you like arts?",
    "Do you like technology?",
    "Do you prefer a quiet life?",
    "Do you prefer drama movies?",
    "Do you enjoy dealing with people?",
    "Do you enjoy working under pressure?",
    "Do you enjoy planning for the future?",
    "Do you like trying new things?",
    "Do you enjoy driving?"
];

const personalityTypes = [
    "Social Personality",
    "Cultural Personality",
    "Adventure Personality",
    "Athletic Personality",
    "Artistic Personality",
    "Technological Personality",
    "Calm Personality",
    "Leadership Personality",
    "Independent Personality",
    "Creative Personality"
];

let currentQuestion = 0;
let answers = [];

const questionContainer = document.getElementById('question');
const resultContainer = document.getElementById('result');

function startGame() {
    document.querySelector('.btn').style.display = 'none';
    showQuestion();
}

function showQuestion() {
    if (currentQuestion < questions.length) {
        document.getElementById('questionText').innerText = questions[currentQuestion];
        questionContainer.style.display = 'block';
    } else {
        calculateResult();
    }
}

function answer(answer) {
    answers.push(answer);
    currentQuestion++;
    showQuestion();
}

function calculateResult() {
    let yesCount = answers.filter(answer => answer).length;
    let resultIndex = Math.floor((yesCount / questions.length) * personalityTypes.length);
    document.getElementById('resultText').innerText = `Your personality: ${personalityTypes[resultIndex]}`;
    resultContainer.style.display = 'block';
}

function restart() {
    currentQuestion = 0;
    answers = [];
    resultContainer.style.display = 'none';
    showQuestion();
}
